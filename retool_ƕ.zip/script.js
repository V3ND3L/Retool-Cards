document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("read").addEventListener("click", () => {
        let backendurl="https://retoolapi.dev/kHPx7e/data";
        fetch(backendurl)
        .then(Response => Response.json())
        .then(data => adatokKartyakba(data));
    });
    function adatokKartyakba(adatok){
        console.log(adatok);
        // adatosorok létrehozása az adatok alapján
        document.getElementById("cards").innerHTML = ``;
        for (let i = 0; i < adatok.length; i++) {
            document.getElementById("cards").innerHTML += ` <div class="card" style="width: 85.6mm; height: 53.98mm; background-image: url(https://picsum.photos/300/200?random=${i}&blur=4); background-size: 100%; -webkit-text-stroke-width: 1px; -webkit-text-stroke-color: black;">
            <div class="card-body">
                <h5 class="card-title text-white"><b>Káryta adatok</b></h5>
                <p class="card-text text-white"><b>Kártyaszám: ${adatok[i].kartyaszam}</b></p>
                <p class="card-text text-white"><b>CVV: ${adatok[i].cvv}</b></p>
                <p class="card-text text-white"><b>Kártyabírtokos neve:<br>${adatok[i].tulajdonos}</b></p>
            </div>
        </div>`;
        }
    }
});